<?php echo $__env->make('control.includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="form-row">
    <div class="form-group col-md-4">
      <label>Primeiro Nome</label>
      <input type="text" class="form-control" placeholder="Nome" name="nome" value="<?php echo e($user->nome ?? ''); ?>">
    </div>
    <div class="form-group col-md-4">
      <label>Último Nome</label>
      <input type="text" class="form-control" placeholder="Sobrenome" name="sobrenome" value="<?php echo e($user->sobrenome ?? ''); ?>">
    </div>
    <div class="form-group col-md2">
      <label>Situação?</label>
      <select name='status' class="form-control">
          <?php if(isset($user)): ?>
        
            <option value="0" <?php echo e($user->s == 0 ? 'selected': ''); ?>>Inativo</option>
            <option value="1" <?php echo e($user->s == 1 ? 'selected': ''); ?>>Ativo</option>
          <?php else: ?>
            <option selected value="">-Escolha-</option>
            <option value="0">Inativo</option>
            <option value="1">Ativo</option>
          <?php endif; ?>
      </select>
    </div>
    <div class="form-group col-md-4">
      <label>E-mail</label>
      <input type="email" class="form-control" placeholder="e-mail" name="email" value="<?php echo e($user->email ?? ''); ?>">
    </div>
    <div class="form-group col-md-4">
      <label>Senha</label>
      <input type="password" class="form-control" placeholder="senha" name="password">
    </div>
  </div>
<button type="submit" class="btn btn-primary">Registrar</button><?php /**PATH C:\xampp\htdocs\ponto\resources\views/control/projects/registers/_partials/form.blade.php ENDPATH**/ ?>