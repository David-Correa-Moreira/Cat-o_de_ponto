<?php $__env->startSection('title', 'Novo Usuário'); ?>



<?php $__env->startSection('content'); ?>
    <div class="card">
        <h4 class="card-header">Insira Novo Usuário</h4>
        <div class="card-body">
            <form action="<?php echo e(route('registers.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo $__env->make('control.projects.registers._partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ponto\resources\views/control/projects/registers/create.blade.php ENDPATH**/ ?>