<?php $__env->startSection('title', "Editar Cadastro de {$user->u}"); ?>



<?php $__env->startSection('content'); ?>
    <div class="card">
        <h4 class="card-header"><strong>Editar Dados do Usuário <?php echo e($user->u); ?></strong></h4>
        <div class="card-body">
            <form action="<?php echo e(route('registers.update', $user->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <?php echo $__env->make('control.projects.registers._partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ponto\resources\views/control/projects/registers/edit.blade.php ENDPATH**/ ?>