<?php $__env->startSection('title', 'Registros'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card text-center">
        <div class="card-header">
            <h3><strong>Histórico de Registros de <?php echo e($user->u); ?></strong></h3>
        </div>
        <div class="card-body">
            <table class="table table-hover">
                <thead>
                  <tr>
                    <th scope="col">Nome</th>
                    <th scope="col">Dia</th>
                    <th scope="col">Entrada</th>
                    <th scope="col">Saída</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $registers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $register): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>   
                        <td><?php echo e($register['user']); ?></td>
                        <td><?php echo e($register['date']); ?></td>
                        <td><?php echo e($register['first']); ?></td>
                        <td><?php echo e($register['last']); ?></td>       
                    </tr> 
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
        </div>
        <div class="card-footer text-muted">
            <strong> Você é muito importante para nós!</strong>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ponto\resources\views/control/projects/registers/show.blade.php ENDPATH**/ ?>