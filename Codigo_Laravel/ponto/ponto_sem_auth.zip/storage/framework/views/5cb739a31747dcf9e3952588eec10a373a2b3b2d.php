<?php $__env->startSection('title', 'Registers'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Usuários</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<div class="card">
    <div class="card-header">
        <a href="<?php echo e(route('registers.create')); ?>" class="btn btn-primary mb-2">Novo Usuário</a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                <tr>

                    <th scope="col">Nome</th>
                    <th scope="col">Situação</th>
                    <th scope="col">Criação</th>
                    <th class="text-center">Ações</th>
                </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($user->u); ?></td>
                            <td><?php echo e($user->s ? 'Ativo': 'Inativo'); ?></td>
                            <td><?php echo e($user->added_at); ?></td>
                            <!-- <td><a href="<?php echo e(route('registers.show', $user->id)); ?>" class="btn btn-info">Ver</a></td>
                            <td>
                                <form action="<?php echo e(route('registers.delete', $user->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">Deletar</button>
                                </form>
                            </td>
                            <td><a href="<?php echo e(route('registers.edit', $user->id)); ?>" class="btn btn-info">Editar</a> </td> -->
                            <td class="text-center">
                                <a href="<?php echo e(route('registers.show', $user->id)); ?>" class="btn btn-info">Ver</a>
                                <form action="<?php echo e(route('registers.delete', $user->id)); ?>" method="POST" style="display: inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">Deletar</button>
                                </form>
                                <a href="<?php echo e(route('registers.edit', $user->id)); ?>" class="btn btn-info">Editar</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
                </tbody>
            </table>
        </div>
    </div>
    <div class="card-footer">
       <small class="text-muted"><?php echo $users->links(); ?></small> 
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ponto\resources\views/control/projects/registers/index.blade.php ENDPATH**/ ?>